<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">
                Xin chào <?php echo $_SESSION['lgFullname'] ?? "<strong style='color:red'> NotLogin </strong>" ?> <br><br>
                Chúc một ngày tốt lành
                </h3>
            </div>
        </div>
    </div>
</div>