</div>
        <section class="engine"></section>
    <section class="cid-qTkA127IK8 thw-fullscreen" id="header2-1">
        <div class="thw-overlay" style="opacity: 0.5; background-color: rgb(118, 118, 118);"></div>

        <div class="container align-center">
            <div class="row justify-content-md-center">
                <div class="thw-white col-md-10">
                    <h1 class="thw-section-title thw-bold pb-3 thw-fonts-style display-1">Welcome to Tourist Half Way
                    </h1>

                    <p class="thw-text pb-3 thw-fonts-style display-5">Với khẩu hiệu: "Tận nơi, Tận tình, Tận nhiệt" -
                        Hãy để Tourist Half Way đưa bạn đến với tận cùng của sự hưởng thụ.&nbsp;</p>
                    <p></p>
                    <p></p>
                    <div class="thw-section-btn"><a class="btn btn-md btn-primary display-4" href="<?= base_url("tour/inbound") ?>">Tour
                            Trong Nước</a>
                        <a class="btn btn-md btn-white-outline display-4" href="<?= base_url("tour/outbound") ?>">Tour Ngoài Nước</a></div>
                </div>
            </div>
        </div>
    </section>